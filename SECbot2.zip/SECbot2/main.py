# === 🔧 IMPORTS ===
import os
import requests
from threading import Thread
import discord
from discord.ext import commands
from flask import Flask
from datetime import datetime, timezone, timedelta
import pytz
from discord.abc import Messageable
from bs4 import BeautifulSoup

# === 🔐 ENV-VARIABLEN EINLESEN ===
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN") or ""
SEC_API_KEY = os.getenv("SEC_API_KEY") or ""
CHANNEL_ID_STR = os.getenv("CHANNEL_ID") or "0"

if not DISCORD_TOKEN:
    raise ValueError("❌ DISCORD_TOKEN fehlt")
if not SEC_API_KEY:
    raise ValueError("❌ SEC_API_KEY fehlt")
if CHANNEL_ID_STR == "0":
    raise ValueError("❌ CHANNEL_ID fehlt")

CHANNEL_ID = int(CHANNEL_ID_STR)

print("🔥 Die aktualisierte Version von main.py wurde gestartet!")

# === 🔑 KEYWORDS EINLESEN ===
def load_keywords():
    try:
        with open("keywords.txt", "r") as f:
            return [line.strip().lower() for line in f if line.strip()]
    except FileNotFoundError:
        return []

KEYWORDS = load_keywords()
FORM_TYPES = ["8-K", "6-K"]
SEEN_FILE = "seen_filings.txt"

# === SEEN FILE ===
def load_seen():
    try:
        with open(SEEN_FILE, "r") as f:
            return set(f.read().splitlines())
    except FileNotFoundError:
        return set()

def save_seen(seen):
    with open(SEEN_FILE, "w") as f:
        f.write("\n".join(seen))

# === DISCORD BOT ===
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# === LOGGING ===
def log_to_file(message: str):
    with open("log.txt", "a") as f:
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        f.write(f"[{timestamp}] {message}\n")

# === SEC API FULLTEXT EXTRACTION ===
def extract_fulltext_via_secapi(url):
    try:
        api_url = "https://api.sec-api.io/extractor"
        params = {"url": url, "token": SEC_API_KEY}
        response = requests.get(api_url, params=params, timeout=20)
        if response.status_code == 200:
            return response.json().get("text", "").lower()
        elif response.status_code == 404:
            log_to_file(f"❌ SEC-API Fehler 404: Filing nicht unterstützt: {url}")
        elif response.status_code == 429:
            log_to_file(f"❌ SEC-API Fehler 429: Rate Limit erreicht bei: {url}")
        else:
            log_to_file(f"❌ SEC-API Fehler: {response.status_code} {response.text}")
    except Exception as e:
        log_to_file(f"❌ Fehler bei SEC-API-Abfrage: {e}")
    return ""

# === Fallback HTML Extraction ===
def fallback_extract_html(url):
    try:
        response = requests.get(url, timeout=15)
        soup = BeautifulSoup(response.text, "html.parser")
        return soup.get_text(" ").lower()
    except Exception as e:
        log_to_file(f"❌ HTML-Fallback fehlgeschlagen: {e}")
        return ""

# === KEYWORD MATCHING ===
def match_keywords(filing):
    text_parts = []
    for key in ["description", "summary", "title", "companyNameLong", "text"]:
        val = filing.get(key)
        if isinstance(val, str):
            text_parts.append(val.lower())
    for doc in filing.get("documentFormatFiles", []):
        desc = doc.get("description")
        if isinstance(desc, str):
            text_parts.append(desc.lower())
    combined_text = " ".join(text_parts)
    matches = [kw for kw in KEYWORDS if kw in combined_text]

    reason = "Primärtext"

    if not matches:
        filing_url = filing.get("primaryDocumentUrl") or filing.get("filingUrl")
        if not filing_url and filing.get("documentFormatFiles"):
            filing_url = filing["documentFormatFiles"][0].get("url")
        if filing_url:
            fulltext = extract_fulltext_via_secapi(filing_url)
            if not fulltext:
                fulltext = fallback_extract_html(filing_url)
                reason = "HTML-Fallback"
            else:
                reason = "SEC-API"

            if fulltext:
                matches = [kw for kw in KEYWORDS if kw in fulltext]
                log_to_file(f"🔎 {reason}-Volltext-Snippet: {fulltext[:300]}")
            else:
                log_to_file(f"⚠️ Kein Volltext erhalten ({reason}).")

    if matches:
        log_to_file(f"✅ Keywords gefunden ({reason}): {matches}")
    else:
        log_to_file(f"❌ Keine Keywords gefunden ({reason}).")

    return ", ".join(matches) if matches else f"Unbekannt ({reason})"


# === FILINGS CHECK ===
def check_filings():
    now = datetime.now(timezone.utc)
    try:
        with open("last_success.txt", "r") as f:
            last_success = datetime.strptime(f.read().strip(), "%Y-%m-%d %H:%M UTC").replace(tzinfo=timezone.utc)
            start = now - timedelta(days=7) if (now - last_success).days > 7 else last_success
    except Exception:
        start = now - timedelta(days=7)

    query = {
        "query": " OR ".join([f'\"{kw}\"' for kw in KEYWORDS]),
        "formTypes": FORM_TYPES,
        "startDate": start.strftime("%Y-%m-%d"),
        "endDate": now.strftime("%Y-%m-%d")
    }
    headers = {"Authorization": SEC_API_KEY}

    try:
        response = requests.post("https://api.sec-api.io/full-text-search", json=query, headers=headers)
        result = response.json()
        filings = result.get("filings", [])
        filings.sort(key=lambda f: f.get("filedAt", ""), reverse=True)
        seen = set()
        unique = []
        for f in filings:
            acc = f.get("accessionNo")
            if acc and acc not in seen:
                seen.add(acc)
                unique.append(f)
        return unique, result.get("total", {}).get("value", 0)
    except Exception as e:
        print(f"❌ Fehler bei der Anfrage: {e}")
        return [], 0

#neu 
def check_filings_all():
    now = datetime.now(timezone.utc)
    start = now - timedelta(days=7)

    query = {
        "query": " OR ".join([f'\"{kw}\"' for kw in KEYWORDS]),
        "formTypes": FORM_TYPES,
        "startDate": start.strftime("%Y-%m-%d"),
        "endDate": now.strftime("%Y-%m-%d")
    }
    headers = {"Authorization": SEC_API_KEY}

    try:
        response = requests.post("https://api.sec-api.io/full-text-search", json=query, headers=headers)
        result = response.json()
        filings = result.get("filings", [])
        filings.sort(key=lambda f: f.get("filedAt", ""), reverse=True)
        return filings, result.get("total", {}).get("value", 0)
    except Exception as e:
        print(f"❌ Fehler bei der Anfrage (all): {e}")
        return [], 0

#neu neu

def check_company_today():
    now = datetime.now(timezone.utc)
    today_str = now.strftime("%Y-%m-%d")

    query = {
        "query": '"company"',
        "formTypes": FORM_TYPES,
        "startDate": today_str,
        "endDate": today_str
    }
    headers = {"Authorization": SEC_API_KEY}

    try:
        response = requests.post("https://api.sec-api.io/full-text-search", json=query, headers=headers)
        result = response.json()
        filings = result.get("filings", [])
        filings.sort(key=lambda f: f.get("filedAt", ""), reverse=True)
        return filings, result.get("total", {}).get("value", 0)
    except Exception as e:
        print(f"❌ Fehler bei der Anfrage (forcecompany): {e}")
        return [], 0
        
# === DISCORD MESSAGE SENDING ===
async def send_filings(filings_fn=check_filings):
    print("🚀 send_filings() gestartet...")
    channel = bot.get_channel(CHANNEL_ID)
    if not isinstance(channel, Messageable):
        print("❌ Channel nicht sendbar.")
        return

    filings, total = filings_fn()
    if not filings:
        msg = f"🕒 Keine relevanten Filings gefunden. (API-Gesamt: {total})"
        await channel.send(msg)
        log_to_file(msg)
        return

    seen_acc = load_seen()
    new_acc = set()

    for filing in filings:
        acc = filing.get("accessionNo")
        if not acc or acc in seen_acc:
            continue
        matched_keyword = match_keywords(filing)
        msg = (
            f"📄 **{filing['formType']}** – {filing['companyNameLong']} ({filing.get('ticker', '—')})\n"
            f"🖖 {filing['filedAt']} • 🔍 Keyword(s): {matched_keyword}\n"
            f"🔗 {filing['filingUrl']}")
        await channel.send(msg)
        log_to_file(f"✅ Treffer: {filing['companyNameLong']} – Keyword(s): {matched_keyword}")
        new_acc.add(acc)

    await channel.send(f"📊 Neue relevante Filings: {len(new_acc)}; Relevante gesamt: {len(filings)} (API-Gesamt: {total})")
    seen_acc.update(new_acc)
    save_seen(seen_acc)
    with open("last_success.txt", "w") as f:
        f.write(datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))

# === FLASK SERVER ===
app = Flask("sec")

@app.route("/")
def home():
    return "✅ SEC Bot läuft."

def run_webserver():
    app.run(host="0.0.0.0", port=8080)

# === DISCORD EVENTS & COMMANDS ===
@bot.event
async def on_ready():
    print(f"✅ Bot ist online als: {bot.user}")
    log_to_file("Bot gestartet")
    channel = bot.get_channel(CHANNEL_ID)
    if isinstance(channel, Messageable):
        await channel.send("✅ Bot gestartet & bereit")
    Thread(target=run_webserver, daemon=True).start()

@bot.command()
async def ping(ctx):
    now = datetime.now(timezone.utc)
    mec = now.astimezone(pytz.timezone("Europe/Berlin"))
    await ctx.send(f"🌿 Bot läuft! Letzter Check: {now.strftime('%Y-%m-%d %H:%M UTC')} / {mec.strftime('%H:%M MEC')}")

@bot.command()
async def force(ctx):
    await ctx.send("🔄 Starte manuelle SEC-Suche...")
    await send_filings()

@bot.command()
async def keywords(ctx):
    await ctx.send("🧠 Aktuelle Keywords:\n" + "\n".join(KEYWORDS))

@bot.command()
async def reset(ctx):
    save_seen(set())
    await ctx.send("🔄 Gesehene Filings wurden zurückgesetzt.")

@bot.command()
async def lastcheck(ctx):
    try:
        with open("last_success.txt", "r") as f:
            last_str = f.read().strip()
            utc_dt = datetime.strptime(last_str, "%Y-%m-%d %H:%M UTC").replace(tzinfo=timezone.utc)
            mec_dt = utc_dt.astimezone(pytz.timezone("Europe/Berlin"))
            await ctx.send(f"📁 Letzte erfolgreiche Suche: {last_str} / {mec_dt.strftime('%H:%M MEC')}")
    except FileNotFoundError:
        await ctx.send("ℹ️ Noch keine erfolgreiche Suche registriert.")

#neue forcecompany
@bot.command()
async def forcecompany(ctx):
    await ctx.send("🔎 Suche nach heutigen Filings mit Keyword 'company'...")

    filings, total = check_company_today()
    if not filings:
        await ctx.send("📭 Keine 'company'-Filings für heute gefunden.")
        return

    for filing in filings[:5]:  # nur die ersten 5 zur Sicherheit
        matched_keyword = match_keywords(filing)
        msg = (
            f"📄 **{filing['formType']}** – {filing['companyNameLong']} ({filing.get('ticker', '—')})\n"
            f"🗓️ {filing['filedAt']} • Keyword: {matched_keyword}\n"
            f"🔗 {filing['filingUrl']}")
        await ctx.send(msg)
        
#neue forceweekall Funktion
@bot.command()
async def forceweekall(ctx):
    await ctx.send("🔄 Starte komplette Wochensuche (alle Ergebnisse)...")

    channel = ctx.channel
    filings, total = check_filings_all()

    if not filings:
        await ctx.send(f"🕒 Keine relevanten Filings gefunden. (API-Gesamt: {total})")
        log_to_file("❌ Keine Filings in forceweekall gefunden.")
        return

    count = 0
    for filing in filings:
        matched_keyword = match_keywords(filing)
        msg = (
            f"📄 **{filing['formType']}** – {filing['companyNameLong']} ({filing.get('ticker', '—')})\n"
            f"🖖 {filing['filedAt']} • 🔍 Keyword(s): {matched_keyword}\n"
            f"🔗 {filing['filingUrl']}")
        await channel.send(msg)
        log_to_file(f"📄 forceweekall: {filing['companyNameLong']} – Keyword(s): {matched_keyword}")
        count += 1

    await ctx.send(f"📊 Gezeigte Einträge (inkl. bereits gesehener): {count} (API-Gesamt: {total})")


@bot.command(name="commands")
async def botcommands(ctx):
    cmds = [
        "!ping – Status prüfen",
        "!force – manuelle Suche (nur neue)",
        "!forceweek – manuelle Wochensuche (nur neue)",
        "!forceweekall – komplette Wochensuche (alle)",
        "!forcecompany – testet Bot mit Keyword 'company' (heutige Einträge)",
        "!keywords – Liste der Keywords anzeigen",
        "!lastcheck – Zeitpunkt der letzten Suche",
        "!reset – Zurücksetzen der Seen-Liste",
        "!commands – Übersicht aller Befehle"
    ]
    await ctx.send("📜 Verfügbare Befehle:\n" + "\n".join(cmds))

bot.run(DISCORD_TOKEN)
